import webview
import os
import sys
from urllib.parse import urlparse, parse_qs, unquote
import threading
import time
import ctypes

# Get directory of this script (works both frozen EXE and normal Python)
if getattr(sys, 'frozen', False):
    dir_path = sys._MEIPASS
else:
    dir_path = os.path.dirname(os.path.abspath(__file__))

html_path = os.path.join(dir_path, 'index.html')

# Parse credentials from custom protocol URL if launched from website
# Format: mediaplayer://login?user=+9647913003612&pass=123123
auto_user = ''
auto_pass = ''
auto_vid = ''
auto_token = ''
auto_lesson = ''
auto_api = ''
if len(sys.argv) > 1:
    protocol_url = sys.argv[1]
    try:
        parsed = urlparse(protocol_url)
        params = parse_qs(parsed.query)
        auto_user = params.get('user', [''])[0]
        auto_pass = params.get('pass', [''])[0]
        auto_vid = params.get('vid', [''])[0]
        auto_token = params.get('token', [''])[0]
        auto_lesson = params.get('lesson', [''])[0]
        auto_api = params.get('api', [''])[0]
    except:
        pass

# JS API class to expose Python functions to JavaScript
class Api:
    def __init__(self):
        self._window = None
    
    def set_window(self, window):
        self._window = window
    
    def toggle_fullscreen(self):
        if self._window:
            self._window.toggle_fullscreen()
    
    def get_auto_credentials(self):
        """Return credentials and platform data passed via protocol URL"""
        return {
            'user': auto_user,
            'pass': auto_pass,
            'vid': auto_vid,
            'token': auto_token,
            'lesson': auto_lesson,
            'api': auto_api
        }

api = Api()

def register_protocol():
    import winreg
    try:
        # sys.executable points to the .exe when frozen, otherwise python.exe
        exe_path = sys.executable if getattr(sys, 'frozen', False) else os.path.abspath(__file__)
        key_path = r"Software\Classes\mediaplayer"
        
        # Create or open the registry key in CURRENT_USER to avoid needing Admin rights
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
        winreg.SetValue(key, "", winreg.REG_SZ, "URL:MediaPlayer Protocol")
        winreg.SetValueEx(key, "URL Protocol", 0, winreg.REG_SZ, "")
        
        # Create shell\open\command subkeys
        command_key = winreg.CreateKey(key, r"shell\open\command")
        winreg.SetValue(command_key, "", winreg.REG_SZ, f'"{exe_path}" "%1"')
        winreg.CloseKey(command_key)
        winreg.CloseKey(key)
    except Exception as e:
        print("Failed to register protocol:", e)

# Auto-register protocol on every launch
if getattr(sys, 'frozen', False):
    register_protocol()

# === EXTREME ANTI-SCREEN RECORDING & ANTI-DEBUGGING ===
def extreme_protection_loop():
    WDA_MONITOR = 1
    # Keep enforcing the protection every second in case any other software tries to strip it
    while True:
        try:
            # 1. Anti-Screen Recording (Blacks out the window for screen recorders)
            hwnd = ctypes.windll.user32.FindWindowW(None, 'KeyAcademy Media Player V5')
            if hwnd:
                ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, WDA_MONITOR)
            
            # 2. Anti-Debugging
            if ctypes.windll.kernel32.IsDebuggerPresent():
                os._exit(1)
        except:
            pass
        time.sleep(1)

# Start protection thread
threading.Thread(target=extreme_protection_loop, daemon=True).start()
# =======================================================


# Create window
window = webview.create_window(
    'KeyAcademy Media Player V5',
    url=html_path,
    width=1280,
    height=720,
    resizable=True,
    fullscreen=False,
    min_size=(640, 360),
    background_color='#0a0a0f',
    text_select=False,
    js_api=api
)

api.set_window(window)

webview.start()
