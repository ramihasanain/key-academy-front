#!/bin/bash
cd "$(dirname "$0")"

echo "======================================"
echo "    KeyAcademy Media Player - macOS   "
echo "======================================"
echo "Installing dependencies..."
pip3 install pywebview --quiet 2>/dev/null

echo "Starting Media Player..."
python3 app.py
